import java.sql.*;
import java.util.Scanner;

public class confessionapp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("🕵️ Welcome to the Anonymous Confession Portal");
        System.out.print("Enter your confession: ");
        String message = scanner.nextLine();

        // Optional: You can secretly pass sender_info here
        String sender_info = "device_001"; // just for record, user doesn't know

        try {
            
            // Connect to database
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/confession_db", "root", "Shubham123&");

            String query = "INSERT INTO confessions (message, sender_info) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, message);
            stmt.setString(2, sender_info);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                System.out.println("✅ Your confession has been posted anonymously.");
            } else {
                System.out.println("❌ Failed to post confession.");
            }

            conn.close();
        } catch (Exception e) {
            System.out.println("❌ Error:");
            e.printStackTrace();
        }

        scanner.close();
        
    }
}
